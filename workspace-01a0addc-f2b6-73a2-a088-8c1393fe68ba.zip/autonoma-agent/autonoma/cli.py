"""Interfaz de línea de comandos de Autonoma."""

from __future__ import annotations

import argparse
import logging
import sys
import threading
from getpass import getpass
from pathlib import Path
from typing import Any

from autonoma import __app_name__, __version__
from autonoma.agent import build_agent
from autonoma.config import load_settings, save_api_keys
from autonoma.key_handler import KeyHandler, PanicController, PanicError
from autonoma.notrack_client import NoTrackError

try:
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.theme import Theme

    RICH = True
except ImportError:  # pragma: no cover
    RICH = False
    Console = None  # type: ignore[misc, assignment]


HELP_TEXT = """
Comandos
  /help              esta ayuda
  /quit  /exit       salir
  /key               pegar NOTRACK_API_KEY (no se muestra)
  /brave             pegar BRAVE_API_KEY (opcional)
  /status            claves, knowledge_base, pánico
  /kb                listar notas de knowledge_base
  /clear             borrar historial de conversación
  /panic             detener la tarea en curso (igual que la tecla P)

Pánico
  Pulsa P en cualquier momento mientras hay una tarea en curso.
  El agente interrumpe hilos, cierra HTTP y mata procesos hijos.
""".strip()

BANNER = f"{__app_name__} v{__version__}  ·  agente local  ·  tecla P = pánico"


class _PlainConsole:
    def print(self, *args: Any, **kwargs: Any) -> None:
        kwargs.pop("style", None)
        kwargs.pop("highlight", None)
        text = " ".join(str(a) for a in args)
        print(text)

    def input(self, prompt: str = "") -> str:
        return input(prompt)


def _console() -> Any:
    if RICH:
        theme = Theme(
            {
                "ok": "green",
                "warn": "yellow",
                "err": "bold red",
                "muted": "dim",
                "accent": "cyan",
            }
        )
        return Console(theme=theme, highlight=False)
    return _PlainConsole()


def _setup_logging(log_dir: Path) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    logfile = log_dir / "autonoma.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(logfile, encoding="utf-8"),
        ],
    )


def _configure_stdio() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass


def _print_banner(console: Any, key_ok: bool, listener_ok: bool, listener_err: str | None) -> None:
    panic_line = "Listener P: activo" if listener_ok else f"Listener P: inactivo — usa /panic. {listener_err or ''}"
    key_line = "NoTrack: clave configurada" if key_ok else "NoTrack: FALTA NOTRACK_API_KEY  →  /key"
    body = f"{BANNER}\n{key_line}\n{panic_line}\nEscribe un prompt o /help"
    if RICH:
        console.print(Panel(body, title=__app_name__, border_style="cyan"))
    else:
        console.print("=" * 60)
        console.print(body)
        console.print("=" * 60)


def _need_key(console: Any, settings: Any) -> None:
    if settings.has_notrack_key:
        return
    console.print(
        "No hay NOTRACK_API_KEY. Consíguela en https://notrack.ai/api-keys "
        "y pégala ahora (no se muestra). Vacío = más tarde con /key.",
        style="warn",
    )
    try:
        value = getpass("NOTRACK_API_KEY: ").strip()
    except (EOFError, KeyboardInterrupt):
        return
    if value:
        save_api_keys(notrack_api_key=value)
        settings.notrack_api_key = value
        console.print("Clave guardada en .env", style="ok")


class Session:
    def __init__(self, console: Any) -> None:
        self.console = console
        self.settings = load_settings()
        _setup_logging(self.settings.log_path())
        self.panic = PanicController()
        self.handler = KeyHandler(self.panic)
        self.listener_ok = self.handler.start()
        _need_key(console, self.settings)
        self.agent = build_agent(self.settings, self.panic)
        self._rebuild_needed = False

    def rebuild_agent(self) -> None:
        self.settings = load_settings()
        self.agent.notrack.close()
        self.agent.search.close()
        self.agent.fs.kill_all()
        self.agent = build_agent(self.settings, self.panic)

    def status(self) -> None:
        s = self.settings
        kb = list(self.agent.search.list_notes(8))
        lines = [
            f"NoTrack key : {'sí (' + s.notrack_api_key[-6:] + ')' if s.has_notrack_key else 'NO'}",
            f"NoTrack URL : {s.notrack_base_url}",
            f"Modelo      : {s.notrack_model}",
            f"Brave key   : {'sí' if s.has_brave_key else 'no (se usará Playwright/HTML)'}",
            f"knowledge   : {s.knowledge_path()}  ({len(list(s.knowledge_path().glob('*.md')))} md)",
            f"pánico P    : {'activo' if self.listener_ok else 'inactivo'}",
            f"tarea       : {'en curso' if self.panic.busy else 'idle'}",
        ]
        if kb:
            lines.append("notas recientes:")
            lines.extend(f"  - {p.name}" for p in kb)
        self.console.print("\n".join(lines))

    def run_prompt(self, prompt: str) -> None:
        if not self.agent.notrack.configured:
            self.console.print("Configura la clave con /key antes de ejecutar prompts.", style="err")
            return

        stop_spinner = threading.Event()
        current = {"msg": "pensando…"}

        def spin() -> None:
            if not RICH:
                return
            frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
            i = 0
            from rich.live import Live
            from rich.text import Text

            try:
                with Live(console=self.console, refresh_per_second=12, transient=True) as live:
                    while not stop_spinner.is_set():
                        frame = frames[i % len(frames)]
                        live.update(Text(f"{frame}  {current['msg']}", style="accent"))
                        i += 1
                        stop_spinner.wait(0.08)
            except Exception:  # noqa: BLE001
                pass

        spinner_thread: threading.Thread | None = None
        if RICH:
            spinner_thread = threading.Thread(target=spin, daemon=True)
            spinner_thread.start()

        def on_event(kind: str, message: str) -> None:
            if kind in {"think", "tool"}:
                current["msg"] = message.replace("\n", " ")[:120]
            if kind == "tool":
                stop_spinner.set()
                self.console.print(f"▸ herramienta  {message}", style="accent")
            elif kind == "tool_result":
                preview = message.replace("\n", " ")[:240]
                self.console.print(f"  ↳ {preview}", style="muted")
            elif kind == "panic":
                stop_spinner.set()
                self.console.print("Detenido por usuario", style="err")

        try:
            answer = self.agent.run(prompt, on_event=on_event)
        except PanicError:
            stop_spinner.set()
            self.console.print("Detenido por usuario", style="err")
            return
        except NoTrackError as exc:
            stop_spinner.set()
            self.console.print(f"NoTrack: {exc}", style="err")
            return
        except Exception as exc:  # noqa: BLE001
            stop_spinner.set()
            logging.exception("Fallo en el agente")
            self.console.print(f"Error: {exc}", style="err")
            return
        finally:
            stop_spinner.set()
            if spinner_thread is not None:
                spinner_thread.join(timeout=1.0)

        self.console.print()
        if RICH:
            self.console.print(Panel(Markdown(answer or ""), title="Autonoma", border_style="green"))
        else:
            self.console.print(answer)

    def handle_command(self, raw: str) -> bool:
        """True = seguir el REPL, False = salir."""
        cmd, _, rest = raw.strip().partition(" ")
        cmd = cmd.lower()
        if cmd in {"/quit", "/exit", "/q"}:
            return False
        if cmd in {"/help", "/h", "/?"}:
            self.console.print(HELP_TEXT)
            return True
        if cmd == "/status":
            self.status()
            return True
        if cmd == "/clear":
            self.agent.reset_history()
            self.console.print("Historial borrado.", style="ok")
            return True
        if cmd == "/panic":
            self.panic.panic()
            self.console.print("Detenido por usuario", style="err")
            return True
        if cmd == "/kb":
            files = self.agent.search.list_notes(40)
            if not files:
                self.console.print("knowledge_base vacía", style="muted")
            else:
                for p in files:
                    self.console.print(f"  {p.name}")
            return True
        if cmd == "/key":
            try:
                value = (rest.strip() or getpass("NOTRACK_API_KEY: ")).strip()
            except (EOFError, KeyboardInterrupt):
                return True
            if value:
                save_api_keys(notrack_api_key=value)
                self.settings.notrack_api_key = value
                self.rebuild_agent()
                self.console.print("NOTRACK_API_KEY guardada.", style="ok")
            return True
        if cmd == "/brave":
            try:
                value = (rest.strip() or getpass("BRAVE_API_KEY: ")).strip()
            except (EOFError, KeyboardInterrupt):
                return True
            save_api_keys(brave_api_key=value)
            self.settings.brave_api_key = value
            self.rebuild_agent()
            self.console.print("BRAVE_API_KEY actualizada.", style="ok")
            return True
        self.console.print(f"Comando desconocido: {cmd}. /help", style="warn")
        return True

    def close(self) -> None:
        try:
            self.panic.panic()
        except Exception:  # noqa: BLE001
            pass
        try:
            self.handler.stop()
        except Exception:  # noqa: BLE001
            pass
        try:
            self.agent.notrack.close()
            self.agent.search.shutdown()
            self.agent.fs.kill_all()
        except Exception:  # noqa: BLE001
            pass


def repl(once: str | None = None) -> int:
    _configure_stdio()
    console = _console()
    session = Session(console)
    _print_banner(
        console,
        key_ok=session.settings.has_notrack_key,
        listener_ok=session.listener_ok,
        listener_err=session.handler.last_error,
    )
    try:
        if once:
            session.run_prompt(once)
            return 0
        while True:
            try:
                raw = console.input("\n[accent]autonoma[/accent] › ") if RICH else console.input("\nautonoma › ")
            except (EOFError, KeyboardInterrupt):
                console.print("\nAdiós.")
                break
            raw = (raw or "").strip()
            if not raw:
                continue
            if raw.startswith("/"):
                if not session.handle_command(raw):
                    console.print("Adiós.")
                    break
                continue
            session.run_prompt(raw)
        return 0
    finally:
        session.close()


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="autonoma",
        description="Agente local autónomo: web, archivos y NoTrack.ai. Tecla P = pánico.",
    )
    parser.add_argument("prompt", nargs="*", help="Instrucción única (sin REPL)")
    parser.add_argument("--version", action="version", version=f"{__app_name__} {__version__}")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    prompt = " ".join(args.prompt).strip() or None
    code = repl(once=prompt)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
