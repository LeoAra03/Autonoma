"""Cliente HTTP para la API OpenAI-compatible de NoTrack.ai."""

from __future__ import annotations

import json
import logging
from collections.abc import Callable, Iterator
from typing import Any

import httpx

from autonoma.key_handler import PanicController, PanicError

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://api.notrack.ai/v1"
DEFAULT_MODEL = "notrack-uncensored"


class NoTrackError(RuntimeError):
    """Error de red, autenticación o contrato de la API."""


class NoTrackClient:
    """Envía consultas a https://api.notrack.ai/v1 (chat/completions)."""

    def __init__(
        self,
        api_key: str,
        panic: PanicController,
        base_url: str = DEFAULT_BASE_URL,
        model: str = DEFAULT_MODEL,
        timeout: float = 120.0,
        persona: str = "notrack",
    ) -> None:
        self.api_key = (api_key or "").strip()
        self.panic = panic
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.model = model or DEFAULT_MODEL
        self.timeout = timeout
        self.persona = persona
        self._client: httpx.Client | None = None
        panic.register_cleanup(self.close)

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    def _ensure_client(self) -> httpx.Client:
        if self._client is None or self._client.is_closed:
            self._client = httpx.Client(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout, connect=15.0),
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "User-Agent": "Autonoma/1.0",
                },
                follow_redirects=True,
            )
        return self._client

    def close(self) -> None:
        client = self._client
        self._client = None
        if client is not None and not client.is_closed:
            try:
                client.close()
            except Exception as exc:  # noqa: BLE001
                logger.debug("Cierre de NoTrackClient: %s", exc)

    def _raise_for_status(self, response: httpx.Response) -> None:
        if response.status_code < 400:
            return
        payload: dict[str, Any] = {}
        try:
            payload = response.json()
        except Exception:  # noqa: BLE001
            payload = {}
        err = payload.get("error") if isinstance(payload, dict) else None
        if isinstance(err, dict):
            kind = err.get("type") or "error"
            message = err.get("message") or response.text[:400]
        else:
            kind = f"http_{response.status_code}"
            message = (response.text or "")[:400] or response.reason_phrase
        raise NoTrackError(f"NoTrack API [{response.status_code}/{kind}]: {message}")

    def _payload(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        temperature: float = 0.4,
        max_tokens: int = 4096,
        stream: bool = False,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
            "notrack": {"persona": self.persona},
        }
        if tools:
            body["tools"] = tools
            if tool_choice is not None:
                body["tool_choice"] = tool_choice
        if extra:
            body.update(extra)
        return body

    def chat(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        temperature: float = 0.4,
        max_tokens: int = 4096,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Completión no streaming. Cancelable vía PanicController."""
        if not self.configured:
            raise NoTrackError(
                "Falta NOTRACK_API_KEY. Créalas en https://notrack.ai/api-keys "
                "y pégala con /key o en el archivo .env"
            )
        self.panic.check()
        client = self._ensure_client()
        body = self._payload(
            messages,
            tools=tools,
            tool_choice=tool_choice,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=False,
            extra=extra,
        )
        try:
            response = client.post("/chat/completions", json=body)
        except httpx.TransportError as exc:
            self.panic.check()
            raise NoTrackError(f"Red / NoTrack: {exc}") from exc
        self.panic.check()
        self._raise_for_status(response)
        try:
            data = response.json()
        except json.JSONDecodeError as exc:
            raise NoTrackError("La API de NoTrack no devolvió JSON válido") from exc
        return data

    def chat_stream(
        self,
        messages: list[dict[str, Any]],
        *,
        temperature: float = 0.4,
        max_tokens: int = 4096,
        on_delta: Callable[[str], None] | None = None,
    ) -> str:
        """Streaming SSE. on_delta recibe cada fragmento de texto."""
        if not self.configured:
            raise NoTrackError("Falta NOTRACK_API_KEY")
        self.panic.check()
        client = self._ensure_client()
        body = self._payload(
            messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
        )
        pieces: list[str] = []
        try:
            with client.stream("POST", "/chat/completions", json=body) as response:
                if response.status_code >= 400:
                    raw = response.read()
                    fake = httpx.Response(
                        status_code=response.status_code,
                        content=raw,
                        request=response.request,
                    )
                    self._raise_for_status(fake)
                for line in self._iter_sse_lines(response):
                    self.panic.check()
                    if line == "[DONE]":
                        break
                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    choices = chunk.get("choices") or []
                    if not choices:
                        continue
                    delta = (choices[0] or {}).get("delta") or {}
                    content = delta.get("content") or ""
                    if content:
                        pieces.append(content)
                        if on_delta:
                            on_delta(content)
        except PanicError:
            raise
        except httpx.TransportError as exc:
            self.panic.check()
            raise NoTrackError(f"Red / NoTrack (stream): {exc}") from exc
        return "".join(pieces)

    def _iter_sse_lines(self, response: httpx.Response) -> Iterator[str]:
        buffer = ""
        for raw in response.iter_text():
            self.panic.check()
            buffer += raw
            while "\n" in buffer:
                line, _, buffer = buffer.partition("\n")
                line = line.strip()
                if not line:
                    continue
                if line.startswith("data:"):
                    yield line[5:].strip()

    def extract_message(self, completion: dict[str, Any]) -> dict[str, Any]:
        choices = completion.get("choices") or []
        if not choices:
            raise NoTrackError("NoTrack no devolvió choices")
        message = (choices[0] or {}).get("message") or {}
        if not isinstance(message, dict):
            raise NoTrackError("Formato de message inesperado")
        return message

    def think(
        self,
        user_prompt: str,
        *,
        system: str,
        history: list[dict[str, Any]] | None = None,
        tools: list[dict[str, Any]] | None = None,
        extra_context: str = "",
    ) -> dict[str, Any]:
        """Atajo: arma el turno y llama a chat()."""
        messages: list[dict[str, Any]] = [{"role": "system", "content": system}]
        if extra_context:
            messages.append(
                {
                    "role": "system",
                    "content": extra_context,
                }
            )
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": user_prompt})
        return self.chat(messages, tools=tools)
