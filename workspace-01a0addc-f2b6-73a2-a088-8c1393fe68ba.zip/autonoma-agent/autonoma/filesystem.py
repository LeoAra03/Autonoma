"""Manipulación de archivos y ejecución de procesos con capa de seguridad."""

from __future__ import annotations

import logging
import os
import shutil
import signal
import subprocess
import threading
from pathlib import Path
from typing import Any

from autonoma.key_handler import PanicController, PanicError

logger = logging.getLogger(__name__)


class FileSystemError(RuntimeError):
    """Error de E/S o de política de seguridad."""


def _win_env_path(name: str) -> Path | None:
    raw = os.environ.get(name)
    if not raw:
        return None
    try:
        return Path(raw).resolve()
    except OSError:
        return None


def _default_protected() -> list[Path]:
    paths: list[Path] = []
    if os.name == "nt":
        candidates = [
            Path(r"C:\Windows"),
            Path(r"C:\Windows\System32"),
            Path(r"C:\Windows\SysWOW64"),
            Path(r"C:\Program Files"),
            Path(r"C:\Program Files (x86)"),
            Path(r"C:\ProgramData"),
            Path(r"C:\Recovery"),
            Path(r"C:\$Recycle.Bin"),
            Path(r"C:\System Volume Information"),
            Path(r"C:\Boot"),
            Path(r"C:\EFI"),
        ]
        for env_name in ("WINDIR", "SYSTEMROOT", "PROGRAMFILES", "PROGRAMFILES(X86)", "PROGRAMDATA"):
            extra = _win_env_path(env_name)
            if extra:
                candidates.append(extra)
        paths.extend(candidates)
    else:
        candidates = [
            Path("/"),
            Path("/etc"),
            Path("/usr"),
            Path("/bin"),
            Path("/sbin"),
            Path("/lib"),
            Path("/lib64"),
            Path("/boot"),
            Path("/dev"),
            Path("/proc"),
            Path("/sys"),
            Path("/root"),
            Path("/run"),
            Path("/snap"),
            Path("/System"),
            Path("/Library"),
            Path("/private/etc"),
            Path("/private/var"),
            Path("/Applications"),
            Path("/usr/local/bin"),  # only as prefix of itself, see is_protected
        ]
        paths.extend(candidates)
    resolved: list[Path] = []
    for p in paths:
        try:
            resolved.append(p.resolve())
        except OSError:
            resolved.append(p)
    return resolved


class FileSystemManager:
    """Leer, escribir, copiar, mover, borrar y lanzar procesos con protecciones."""

    def __init__(
        self,
        panic: PanicController,
        extra_protected: list[str] | None = None,
        command_timeout: float = 60.0,
    ) -> None:
        self.panic = panic
        self.command_timeout = command_timeout
        self._protected = _default_protected()
        if extra_protected:
            for raw in extra_protected:
                try:
                    self._protected.append(Path(raw).expanduser().resolve())
                except OSError:
                    self._protected.append(Path(raw))
        self._procs: list[subprocess.Popen[str]] = []
        self._proc_lock = threading.Lock()
        panic.register_cleanup(self.kill_all)

    # ------------------------------------------------------------------ safety
    def resolve(self, path: str | Path) -> Path:
        return Path(path).expanduser().resolve()

    def is_protected(self, path: str | Path) -> bool:
        """True si la ruta es (o está dentro de) un directorio crítico del SO."""
        try:
            target = self.resolve(path)
        except OSError:
            target = Path(path).expanduser()

        # En Unix, bloquear "/" como destino de delete/move, pero no todo lo que cuelga de /.
        unix_root_only = {Path("/")}
        for protected in self._protected:
            try:
                prot = protected.resolve()
            except OSError:
                prot = protected
            if os.name != "nt" and prot in unix_root_only:
                if target == prot:
                    return True
                continue
            if target == prot:
                return True
            try:
                if target.is_relative_to(prot):
                    return True
            except (ValueError, TypeError, OSError):
                try:
                    target.relative_to(prot)
                    return True
                except ValueError:
                    continue
        return False

    def _assert_writable(self, path: str | Path, *, force: bool, user_prompt: str) -> Path:
        target = self.resolve(path)
        if not self.is_protected(target):
            return target
        mentioned = str(target).lower() in (user_prompt or "").lower() or str(path).lower() in (
            user_prompt or ""
        ).lower()
        if force and mentioned:
            logger.warning("OVERRIDE de ruta protegida autorizado explícitamente: %s", target)
            return target
        raise FileSystemError(
            f"Ruta protegida del sistema operativo: {target}. "
            "La operación se bloqueó. Para forzarla, la instrucción del usuario debe "
            "mencionar la ruta exacta y el parámetro force=true de la herramienta."
        )

    def _assert_not_protected_delete(self, path: str | Path, *, force: bool, user_prompt: str) -> Path:
        return self._assert_writable(path, force=force, user_prompt=user_prompt)

    # ------------------------------------------------------------------- CRUD
    def read_file(self, path: str, max_chars: int = 80_000) -> str:
        self.panic.check()
        target = self.resolve(path)
        if not target.exists():
            raise FileSystemError(f"No existe: {target}")
        if target.is_dir():
            raise FileSystemError(f"Es un directorio, no un archivo: {target}")
        try:
            data = target.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            raise FileSystemError(f"No se pudo leer {target}: {exc}") from exc
        if len(data) > max_chars:
            return data[:max_chars] + f"\n\n…[truncado, {len(data)} caracteres en total]"
        return data

    def write_file(self, path: str, content: str, *, force: bool = False, user_prompt: str = "") -> str:
        self.panic.check()
        target = self._assert_writable(path, force=force, user_prompt=user_prompt)
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
        except OSError as exc:
            raise FileSystemError(f"No se pudo escribir {target}: {exc}") from exc
        return f"Escrito {target} ({len(content)} caracteres)"

    def append_file(self, path: str, content: str, *, force: bool = False, user_prompt: str = "") -> str:
        self.panic.check()
        target = self._assert_writable(path, force=force, user_prompt=user_prompt)
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("a", encoding="utf-8") as fh:
                fh.write(content)
        except OSError as exc:
            raise FileSystemError(f"No se pudo anexar {target}: {exc}") from exc
        return f"Anexado a {target}"

    def copy_path(self, src: str, dst: str, *, force: bool = False, user_prompt: str = "") -> str:
        self.panic.check()
        source = self.resolve(src)
        dest = self._assert_writable(dst, force=force, user_prompt=user_prompt)
        if not source.exists():
            raise FileSystemError(f"Origen no existe: {source}")
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            if source.is_dir():
                shutil.copytree(source, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(source, dest)
        except OSError as exc:
            raise FileSystemError(f"Copia falló: {exc}") from exc
        return f"Copiado {source} → {dest}"

    def move_path(self, src: str, dst: str, *, force: bool = False, user_prompt: str = "") -> str:
        self.panic.check()
        source = self._assert_not_protected_delete(src, force=force, user_prompt=user_prompt)
        dest = self._assert_writable(dst, force=force, user_prompt=user_prompt)
        if not source.exists():
            raise FileSystemError(f"Origen no existe: {source}")
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(dest))
        except OSError as exc:
            raise FileSystemError(f"Movimiento falló: {exc}") from exc
        return f"Movido {source} → {dest}"

    def delete_path(self, path: str, *, force: bool = False, user_prompt: str = "") -> str:
        self.panic.check()
        target = self._assert_not_protected_delete(path, force=force, user_prompt=user_prompt)
        if not target.exists():
            raise FileSystemError(f"No existe: {target}")
        try:
            if target.is_dir():
                shutil.rmtree(target)
                return f"Directorio eliminado: {target}"
            target.unlink()
            return f"Archivo eliminado: {target}"
        except OSError as exc:
            raise FileSystemError(f"No se pudo eliminar {target}: {exc}") from exc

    def list_dir(self, path: str, max_entries: int = 400) -> str:
        self.panic.check()
        target = self.resolve(path)
        if not target.exists():
            raise FileSystemError(f"No existe: {target}")
        if not target.is_dir():
            raise FileSystemError(f"No es un directorio: {target}")
        try:
            entries = sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except OSError as exc:
            raise FileSystemError(f"No se pudo listar {target}: {exc}") from exc
        lines: list[str] = [f"{target} ({len(entries)} entradas)"]
        for item in entries[:max_entries]:
            kind = "dir " if item.is_dir() else "file"
            size = ""
            try:
                if item.is_file():
                    size = f" {item.stat().st_size}B"
            except OSError:
                size = ""
            lines.append(f"  [{kind}] {item.name}{size}")
        if len(entries) > max_entries:
            lines.append(f"  … +{len(entries) - max_entries} más")
        return "\n".join(lines)

    def mkdir(self, path: str, *, force: bool = False, user_prompt: str = "") -> str:
        self.panic.check()
        target = self._assert_writable(path, force=force, user_prompt=user_prompt)
        try:
            target.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise FileSystemError(f"No se pudo crear directorio {target}: {exc}") from exc
        return f"Directorio listo: {target}"

    # --------------------------------------------------------------- processes
    def run_command(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: float | None = None,
        shell: bool = True,
    ) -> dict[str, Any]:
        """Ejecuta un programa externo. Cancelable con la tecla P."""
        self.panic.check()
        timeout = timeout if timeout is not None else self.command_timeout
        cwd_path = self.resolve(cwd) if cwd else Path.cwd()
        if not cwd_path.is_dir():
            raise FileSystemError(f"cwd inválido: {cwd_path}")

        kwargs: dict[str, Any] = {
            "args": command if shell else command.split(),
            "cwd": str(cwd_path),
            "stdout": subprocess.PIPE,
            "stderr": subprocess.PIPE,
            "text": True,
            "encoding": "utf-8",
            "errors": "replace",
            "shell": shell,
        }
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            kwargs["creationflags"] = flags
        else:
            kwargs["start_new_session"] = True

        try:
            proc = subprocess.Popen(**kwargs)
        except OSError as exc:
            raise FileSystemError(f"No se pudo lanzar el proceso: {exc}") from exc

        with self._proc_lock:
            self._procs.append(proc)

        try:
            deadline = timeout
            slice_s = 0.2
            elapsed = 0.0
            while proc.poll() is None:
                self.panic.check()
                try:
                    proc.wait(timeout=slice_s)
                except subprocess.TimeoutExpired:
                    elapsed += slice_s
                    if deadline is not None and elapsed >= deadline:
                        self._kill_proc(proc)
                        raise FileSystemError(
                            f"Timeout ({deadline}s) ejecutando: {command}"
                        ) from None
            stdout, stderr = proc.communicate(timeout=5)
        except PanicError:
            self._kill_proc(proc)
            raise
        finally:
            with self._proc_lock:
                if proc in self._procs:
                    self._procs.remove(proc)

        out = (stdout or "")[-12_000:]
        err = (stderr or "")[-8_000:]
        return {
            "command": command,
            "returncode": proc.returncode,
            "stdout": out,
            "stderr": err,
        }

    def _kill_proc(self, proc: subprocess.Popen[str]) -> None:
        if proc.poll() is not None:
            return
        try:
            if os.name == "nt":
                proc.terminate()
                try:
                    proc.wait(timeout=1.5)
                except subprocess.TimeoutExpired:
                    proc.kill()
            else:
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except OSError:
                    proc.terminate()
                try:
                    proc.wait(timeout=1.5)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except OSError:
                        proc.kill()
        except OSError as exc:
            logger.debug("kill proc %s: %s", proc.pid, exc)
        try:
            import psutil  # type: ignore[import-not-found]

            try:
                parent = psutil.Process(proc.pid)
            except psutil.Error:
                return
            children = parent.children(recursive=True)
            for child in children:
                try:
                    child.kill()
                except psutil.Error:
                    pass
            try:
                parent.kill()
            except psutil.Error:
                pass
        except Exception:  # noqa: BLE001
            pass

    def kill_all(self) -> None:
        with self._proc_lock:
            procs = list(self._procs)
        for proc in procs:
            self._kill_proc(proc)

    def format_command_result(self, result: dict[str, Any]) -> str:
        parts = [
            f"$ {result.get('command')}",
            f"exit={result.get('returncode')}",
        ]
        if result.get("stdout"):
            parts.append("--- stdout ---\n" + str(result["stdout"]))
        if result.get("stderr"):
            parts.append("--- stderr ---\n" + str(result["stderr"]))
        return "\n".join(parts)
