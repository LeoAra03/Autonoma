# Autonoma

Agente de software local (Windows / Linux / macOS). Recibe un prompt, razona con la API de [NoTrack.ai](https://notrack.ai/), investiga en la web, manipula archivos y puede lanzar programas. La tecla **P** detiene cualquier tarea en curso.

Requiere **Python 3.10+**.

## Arquitectura

```
autonoma/
  agent.py            Agent — bucle de pensamiento + herramientas
  search_engine.py    SearchEngine — Brave API / Playwright / HTML
  filesystem.py       FileSystemManager — E/S + subprocess + rutas protegidas
  notrack_client.py   NoTrackClient — https://api.notrack.ai/v1
  key_handler.py      KeyHandler + PanicController — tecla P
  config.py           NOTRACK_API_KEY, BRAVE_API_KEY, .env
  cli.py              interfaz de línea de comandos
knowledge_base/       hallazgos persistidos (.md)
```

## Instalación

```bash
cd autonoma-agent
python -m venv .venv

# Windows
.venv\Scripts\activate
# Linux / macOS
source .venv/bin/activate

pip install -r requirements.txt

# Opcional: navegador para el fallback Playwright
playwright install chromium
```

Copia `.env.example` a `.env` y pega tu clave:

```env
NOTRACK_API_KEY=sk-notrack-pega-aqui-tu-clave
BRAVE_API_KEY=
```

La clave de NoTrack se crea en [https://notrack.ai/api-keys](https://notrack.ai/api-keys) (API OpenAI-compatible, modelo `notrack-uncensored`). Si no pones `BRAVE_API_KEY`, el agente busca en Brave Search con Playwright (si Brave Browser o Chromium están instalados) o con un scrape HTML.

También puedes pegar las claves en runtime con `/key` y `/brave`.

## Uso

```bash
# REPL interactivo
python -m autonoma
# o
python run_autonoma.py

# Un solo prompt
python -m autonoma "Investiga el estado actual de la API de Brave Search y guarda un resumen"
```

Comandos dentro del REPL:

| Comando   | Efecto                                      |
|-----------|---------------------------------------------|
| `/help`   | ayuda                                       |
| `/key`    | guardar `NOTRACK_API_KEY`                   |
| `/brave`  | guardar `BRAVE_API_KEY`                     |
| `/status` | claves, knowledge_base, listener            |
| `/kb`     | listar notas                                |
| `/clear`  | borrar historial de conversación            |
| `/panic`  | detener la tarea (igual que la tecla P)     |
| `/quit`   | salir                                       |

## Botón de pánico (tecla P)

Un listener de `pynput` corre en un **hilo daemon** y no bloquea la CLI.

- Mientras hay una tarea en curso, pulsar **P** (mayúscula o minúscula) activa el pánico.
- Se cancela HTTP (NoTrack y búsquedas), se matan procesos hijos y el agente muestra **«Detenido por usuario»**.
- En sesiones SSH / sin display, usa `/panic`.
- En Linux, el listener global suele necesitar X11 o Wayland.

## Investigación (Search & Learn)

Orden de backends:

1. **Brave Search API** (`X-Subscription-Token`) si `BRAVE_API_KEY` está definida.
2. **Playwright** sobre Brave Browser (`search.brave.com`) si está instalado; si no, Chromium.
3. Scrape HTML de Brave Search con `httpx` + BeautifulSoup.

Los hallazgos se guardan en `./knowledge_base/*.md`. El agente los relee como contexto entre instrucciones.

## Sistema de archivos y seguridad

Operaciones: leer, escribir, copiar, mover, borrar, crear carpetas, `subprocess`.

Rutas bloqueadas por defecto (escritura / borrado / movimiento):

- Windows: `C:\Windows`, `System32`, `Program Files`, `ProgramData`, `%WINDIR%`, …
- Unix: `/etc`, `/usr`, `/bin`, `/sbin`, `/boot`, `/dev`, `/proc`, `/sys`, `/root`, `/System`, `/Library`, …

Para saltar el bloqueo hace falta **las dos cosas**: el prompt del usuario debe mencionar la ruta exacta **y** la herramienta debe ir con `force=true`. Un fallo en una herramienta no tumba el proceso.

## Integración NoTrack.ai

```
Base URL : https://api.notrack.ai/v1
Modelo   : notrack-uncensored
Header   : Authorization: Bearer $NOTRACK_API_KEY
```

El cliente habla el contrato OpenAI (`/chat/completions` + `tools`). La respuesta de NoTrack es el «pensamiento» del agente: decide si buscar, tocar el disco, ejecutar un comando o responder.

## Compilar a .exe con PyInstaller

En una máquina Windows, desde la raíz del repo:

```bat
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean autonoma.spec
```

O doble clic en `scripts\build_windows.bat`.

El ejecutable queda en `dist\Autonoma.exe`. Es de consola (`--onefile` vía el `.spec`).

Coloca un archivo `.env` **junto al .exe**:

```env
NOTRACK_API_KEY=sk-notrack-...
BRAVE_API_KEY=
```

Notas:

- El `.exe` no empaqueta Playwright (pesa mucho y exige un navegador). En el binario, la búsqueda usa Brave API o el fallback HTML.
- Primera ejecución: Windows Defender puede escanear el binario de PyInstaller; es normal.
- Para un build más verboso: `python -m PyInstaller --onefile --console --name Autonoma run_autonoma.py`

Linux / macOS: `bash scripts/build.sh` genera `dist/Autonoma`.

## Licencia de uso

Código de ejemplo para uso local. Las claves y el tráfico pertenecen a tus cuentas de NoTrack / Brave. No subas el archivo `.env` a un repositorio público.
