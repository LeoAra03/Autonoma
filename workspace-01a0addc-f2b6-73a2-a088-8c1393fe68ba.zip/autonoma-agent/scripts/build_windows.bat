@echo off
REM Compila Autonoma.exe con PyInstaller (ejecutar desde la raíz del repo).
cd /d "%~dp0\.."
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean autonoma.spec
echo.
echo Listo: dist\Autonoma.exe
echo Coloca un archivo .env junto al .exe con NOTRACK_API_KEY=...
pause
